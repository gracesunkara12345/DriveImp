package com.sepaapi.apitests.sprint2;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessGetSectorTypeTest - CLASS -> HttpGET Request API returns This
 * give you all the sector available in data base.
 *
 */
public class SepaBusinessGetSectorTypeTest extends SepaBase {
	SepaBase sepaBase;
	String businessSectorTypeUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String business_sector_id;

	/**
	 * setUp() - METHOD -> To load the properties file. Return - businessSectorType
	 * API URl(HttpGet)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setUp() throws Exception {
		sepaBase = new SepaBase();
		businessSectorTypeUrl = properties.getProperty("businessSectorType");
	}

	/**
	 * getSectorTypes() - METHOD -> To execute the HTTPGET
	 * API(businessGetInsertedFileUrl) It returns all the sector available in data
	 * base as closebaleHttpResponse. We are parsing the obtained API Response and
	 * validating the response based on business_sector_id & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void getSectorTypes() throws Exception {
		sepaRequests = new SepaRequests();
		String usersJsonStringURL = businessSectorTypeUrl;
		closebaleHttpResponse = sepaRequests.get(usersJsonStringURL); // call the API
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		if (responseString.startsWith("[")) {
			JSONArray responseJsonArray = new JSONArray(responseString);
			int count = responseJsonArray.length();
			for (int i = 0; i < count; i++) {
				responseJson = responseJsonArray.getJSONObject(i);
				business_sector_id = ValidationUtils.getValueByJPath(responseJson, "/business_sector_id");
				Assert.assertEquals(Integer.parseInt(business_sector_id), i + 1);
			}
		} else {
			responseJson = new JSONObject(responseString);
		}
	}
}

package com.sepaapi.apitests.sprint1;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaGetOTPGenarateTest - HttpGet Request API which generates the OTP
 * Verification code send to the Registered Email_Id *
 */
public class SepaGetGenarateAndVerifyOTPTest extends SepaBase {
	SepaBase sepaBase;
	String emailURL;
	String emailOrMobileOTPGenUrl;
	String verifyOTPURL;
	String verifyEmailOTPFromProp;
	String generatedString;
	String emailOTP;

	/**
	 * setUp() Method - To load the properties file. It generate Email or Mobile
	 * OTP. URl(HttpGet)
	 * 
	 * @throws Exception
	 */
	@BeforeClass
	public void setUp() throws Exception {
		sepaBase = new SepaBase();
		emailOrMobileOTPGenUrl = properties.getProperty("emailOrMobileOTPGen");
		generatedString =properties.getProperty("mobileno");
		emailURL = emailOrMobileOTPGenUrl + generatedString;

	}

	/**
	 * getOTP() Method - To Generate OTP link to the HTTP GET API. It returns
	 * closebaleHttpResponse We are parsing the obtained API Response and validating
	 * the response and Actual Message based on ResponseString and HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */

	@Test(priority=1)
	public void generateOTP() throws Exception {

		JSONObject responseJson;

		SepaRequests sepaRequests;
		CloseableHttpResponse closebaleHttpResponse;
		String actualSuccessMessage;
		String expectedSuccessMesssage = "OTP Sent , Please Varify";
		//String expectedSuccessMesssage = "Message Sent With Varification OTP";
		String actualStatus;
		String expectedStatus = "1";
		sepaRequests = new SepaRequests();
		closebaleHttpResponse = sepaRequests.get(emailURL);
		// a. Status Code:
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200, StatusCode_Err_200);

		// b. Json String:
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		System.out.println(responseString);
		if (responseString.startsWith("[")) {
			JSONArray responseJsonArray = new JSONArray(responseString);
			responseJson = responseJsonArray.getJSONObject(0);
		} else {
			responseJson = new JSONObject(responseString);
		}
		actualSuccessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualSuccessMessage, expectedSuccessMesssage);
		Assert.assertEquals(actualStatus, expectedStatus);
	}

	@Test(priority=2)
	public void verifyOTP() throws Exception {

		JSONObject responseJson;

		SepaRequests sepaRequests;
		CloseableHttpResponse closebaleHttpResponse;
		String expectedSuccessMesssage = "OTP Successfully Verified";
	
	
		String actualSuccessMessage;
		String actualStatus;
		String expectedStatus = "1";

		verifyOTPURL = properties.getProperty("emailOrMobileOTPVerify");
		// verifyEmailOTPFromProp = properties.getProperty("verifyEmail");
	//	Thread.sleep(5000);
		String OTP = ReadOTP(generatedString);
		System.out.println(generatedString);
		emailOTP = verifyOTPURL+generatedString+"/" +OTP;


		sepaRequests = new SepaRequests();
		closebaleHttpResponse = sepaRequests.get(emailOTP);

		// a. Status Code:
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200, StatusCode_Err_200);

		// b. Json String:
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		System.out.println(responseString);

		if (responseString.startsWith("[")) {
			JSONArray responseJsonArray = new JSONArray(responseString);
			responseJson = responseJsonArray.getJSONObject(0);
		} else {
			responseJson = new JSONObject(responseString);
		}

		actualSuccessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualSuccessMessage, expectedSuccessMesssage);
		Assert.assertEquals(actualStatus, expectedStatus);
		
	}

}

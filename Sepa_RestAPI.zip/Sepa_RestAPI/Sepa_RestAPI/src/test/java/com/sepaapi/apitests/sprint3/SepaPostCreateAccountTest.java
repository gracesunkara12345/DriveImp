package com.sepaapi.apitests.sprint3;

import java.util.HashMap;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.apitests.sprint2.SepaSprint2Base;
import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

public class SepaPostCreateAccountTest extends SepaBase{

	SepaBase sepaBase;
	String CreateAccountUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String expectedSuccessMesssage = "Insert successfully";
	String actualSuccessMessage;
	String actualStatus;
	String expectedStatus = "1";

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessPostRegistration API URl(HttpPost)
	 * 
	 * @throws Exception
	 */

	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		CreateAccountUrl = properties.getProperty("PostCreateAccount");
	}

	/**
	 * businessRegistration() - METHOD -> To execute the HttpPost
	 * (businessChangePassword)API. This API is used to register company and It
	 * returns JsonResponse and We are parsing the obtained API Response and
	 * validating the response based on Message, status & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void businessRegistration() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestData_Path,
				"CreateAccountDetails");
		// Data Drive from Excel
		String usersJsonString = excelUtils.DataEntry(0);
		// Json String
		StringBuffer st = new StringBuffer(usersJsonString);
		st.insert(16, SepaSprint2Base.APPLICANT_ID);
		String stringRegReq = st.toString();
		System.out.println("stringRegReq"+stringRegReq);
		requestJSON = new JSONObject(stringRegReq);
		closebaleHttpResponse = sepaRequests.post(CreateAccountUrl, stringRegReq, headerMap);
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		responseJson = new JSONObject(responseString);
		System.out.println("responseJson"+responseJson);
		actualSuccessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualSuccessMessage, expectedSuccessMesssage);
		Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
	}

}

package com.sepaapi.apitests.sprint2;

import java.util.HashMap;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessPostSetTransactionalModeTest - CLASS -> HttpPost Request , This
 * API used to set transactional information for business .
 */
public class SepaBusinessPostSetTransactionalModeTest extends SepaBase {
	SepaBase sepaBase;
	String businessPostTransactionalModeUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String expectedSuccessMesssage = "Transaction countries inserted successfully";
	String actualSuccessMessage;
	String actualStatus;
	String expectedStatus = "1";

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessPostTransactionalMode API URl(HttpPost)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		businessPostTransactionalModeUrl = properties.getProperty("businessPostTransactionalMode");
	}

	/**
	 * setCountryBasedTransactionModes() - METHOD -> To execute the HttpPost
	 * API(businessPostSetTransactionVolume) It returns JsonResponse, This API will
	 * set transactional information for business and we are validating the obtained
	 * API response based on message ,status & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void setCountryBasedTransactionModes() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness,
				"SetcountrybasedtransactionMode");
		int columnCount = excelUtils.getColumnCount();
		// Data Drive from Excel
		String usersJsonString = excelUtils.DataEntry(0);
		// Json String
		StringBuffer st = new StringBuffer(usersJsonString);
		st.insert(46, SepaSprint2Base.BUSINESS_ID);
		st.insert(77, SepaSprint2Base.COUNTRY_ID);
		st.insert(221, SepaSprint2Base.BUSINESS_ID);
		st.insert(252, SepaSprint2Base.COUNTRY_ID);
		String stringRegReq = st.toString();
		requestJSON = new JSONObject(stringRegReq);
		closebaleHttpResponse = sepaRequests.post(businessPostTransactionalModeUrl, stringRegReq, headerMap); // call
		closebaleHttpResponse.getStatusLine().getStatusCode();
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		responseJson = new JSONObject(responseString);
		actualSuccessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualSuccessMessage, expectedSuccessMesssage);
	}
}

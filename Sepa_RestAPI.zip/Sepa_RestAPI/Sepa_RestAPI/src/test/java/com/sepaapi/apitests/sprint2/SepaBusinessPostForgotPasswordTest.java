
package com.sepaapi.apitests.sprint2;

import java.util.HashMap;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.mongodb.util.JSON;
import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessPostForgotPasswordTest - CLASS -> HttpPOST Request API. An Email
 * sent to invitation for re-set new Password.
 *
 */

public class SepaBusinessPostForgotPasswordTest extends SepaBase {
	SepaBase sepaBase;
	String businessPostForgotPassWordUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String actualSuccessMessage;
	String actualStatus;
	String expectedStatus = "1";
	String responseMessageFirstPart = "Email sent to ";
	String responseMessageSecondPart = " , please re-set new password ";

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessPostForgotPassWord API URl(HttpPost)
	 * 
	 * @throws Exception
	 */

	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		businessPostForgotPassWordUrl = properties.getProperty("businessPostForgotPassWord");
	}

	/**
	 * forgotPassword() - METHOD -> To execute the HttpPost
	 * API(businessPostForgotPassWord). It sent email invitation for update new
	 * password as closebaleHttpResponse. We are parsing the obtained API Response
	 * and validating the response based on status,message & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */

	@Test
	public void forgotPassword() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness, "ForgotPassword");
		String usersJsonString = excelUtils.DataEntry(0);
		StringBuffer st = new StringBuffer(usersJsonString);
		st.insert(12, SepaSprint2Base.EMAIL_ID);
		String stringRegReq = st.toString();
		requestJSON = new JSONObject(stringRegReq);
		closebaleHttpResponse = sepaRequests.post(businessPostForgotPassWordUrl, stringRegReq, headerMap);
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		responseJson = new JSONObject(responseString);
		actualSuccessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		String expectedSucessMessage = responseMessageFirstPart + SepaSprint2Base.EMAIL_ID + responseMessageSecondPart;
		Assert.assertEquals(actualSuccessMessage, expectedSucessMessage);
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
	}
}

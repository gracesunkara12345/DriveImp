package com.sepaapi.apitests.sprint1;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ValidationUtils;
/**
 * SepaGetKYCVerificationTest - HttpGet Request API which verifies the KYCVerificationLink send to Mobile number or Email_Id
 *
 */
public class SepaGetKYCVerificationTest extends SepaBase {

	SepaBase sepaBase;
	String verifyKYCUrl;
	String verifyKYCPhone;
	JSONObject responseJson;
	String KYCmainUrl;
	SepaRequests sepaRequests;
	CloseableHttpResponse closebaleHttpResponse;
	String expectedSuccessMesssage = "Link sent to email";
	String actualSuccessMessage;
	String actualStatus;
	String expectedStatus = "1";

	/**
	 * setUp() Method - To load the properties file. Return - KYCVerificationLink by using Mobile Number and Email_Id Verification code.
	 * URl(HttpGet)
	 * @throws Exception
	 */
	
	@BeforeMethod
	public void setUp() throws Exception {
		sepaBase = new SepaBase();
		verifyKYCUrl = properties.getProperty("KYCVerificationLink");
		verifyKYCPhone  = properties.getProperty("verifyKYCPhoneNumber" );
		KYCmainUrl = verifyKYCUrl+verifyKYCPhone;
	
		
	}
	/**
	 * sendKYCVerificationLink() Method  - To Send KYCVerification link to the HTTP GET API.
	 * It returns closebaleHttpResponse 
	 * We are parsing the obtained API Response and validating the response and Actual Message based on ResponseString and HTTPStatus Codes.
	 * @throws Exception
	 */
	
	@Test
	public void sendKYCVerificationLink() throws Exception {
		sepaRequests = new SepaRequests();
		closebaleHttpResponse = sepaRequests.get(KYCmainUrl);

		// a. Status Code:
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200, StatusCode_Err_200);

		// b. Json String:
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		if (responseString.startsWith("[")) {
			JSONArray responseJsonArray = new JSONArray(responseString);
			responseJson = responseJsonArray.getJSONObject(0);
		} else {
			responseJson = new JSONObject(responseString);
		}

		actualSuccessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualSuccessMessage, expectedSuccessMesssage);
		Assert.assertEquals(actualStatus, expectedStatus);
	}
}
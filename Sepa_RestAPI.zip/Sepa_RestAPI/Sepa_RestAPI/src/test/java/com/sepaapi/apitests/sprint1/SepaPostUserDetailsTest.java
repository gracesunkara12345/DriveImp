package com.sepaapi.apitests.sprint1;

import java.util.HashMap;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
* SepaPostUserDetailsTest - HttpPost Request API which Posts verifies User data found or not.
* This API used fectch all the data about a particular user.
*/
public class SepaPostUserDetailsTest extends SepaBase {

	SepaBase sepaBase;
	String userDetailsAPIUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String email;

	/**
	 * setUp() - To load the properties file.
	 * @throws Exception
	 */
	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		userDetailsAPIUrl = properties.getProperty("userDetailsPost");
	}

	/**
	 * postUserDetails() - To execute the HTTPPOST API(UserDetails)
	 * We are parsing the obtained API Response and validating the response based on Actual Message and HTTPStatus Codes.
	 * @throws Exception
	 */
	@Test
	public void getUserDetailsByEmail() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPath,"UserDetails");
		int columnCount = excelUtils.getColumnCount();
		System.out.println(columnCount);

		for (int i = 0; i < columnCount; i++) {
			String usersJsonString = excelUtils.DataEntry(i);
			requestJSON = new JSONObject(usersJsonString);
			String actualEmail = ValidationUtils.getValueByJPath(requestJSON, "/email");
			closebaleHttpResponse = sepaRequests.post(userDetailsAPIUrl, usersJsonString, headerMap); // call the API
			int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
			Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
			String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
			responseJson = new JSONObject(responseString);
			email = ValidationUtils.getValueByJPath(responseJson, "/data/email");
			Assert.assertEquals(actualEmail, email);
		}
	}
}

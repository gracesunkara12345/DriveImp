package com.sepaapi.apitests.sprint2;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessGetInsertedFileStatusTest - CLASS -> HttpGET Request API returns
 * inserted file status details based on businessId.
 *
 */
public class SepaBusinessGetInsertedFileStatusTest extends SepaBase {
	SepaBase sepaBase;
	String businessGetInsertedFileStatusUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String actualSucessMessage = "Data found";
	String excepctedSucessMessage;
	String actualStatus;
	String expectedStatus = "1";

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessGetInsertedFileStatus API URl(HttpGet)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setUp() throws Exception {
		sepaBase = new SepaBase();
		businessGetInsertedFileStatusUrl = properties.getProperty("businessGetInsertedFileStatus");
		businessGetInsertedFileStatusUrl = businessGetInsertedFileStatusUrl + SepaSprint2Base.BUSINESS_ID;
	}

	/**
	 * getInsertedFileStatusByBusinessId() - METHOD -> To execute the HTTPGET
	 * API(businessGetInsertedFileStatus) It returns file insertion status Details
	 * as closebaleHttpResponse. We are parsing the obtained API Response and
	 * validating the response based on businessindustryId,status,message &
	 * HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void getInsertedFileStatusByBusinessId() throws Exception {
		sepaRequests = new SepaRequests();
		closebaleHttpResponse = sepaRequests.get(businessGetInsertedFileStatusUrl); // call the API
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		if (responseString.startsWith("[")) {
			JSONArray responseJsonArray = new JSONArray(responseString);
			int count = responseJsonArray.length();
			for (int i = 0; i < count; i++) {
				responseJson = responseJsonArray.getJSONObject(i);
			}
		} else {
			responseJson = new JSONObject(responseString);
		}
		excepctedSucessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		Assert.assertEquals(excepctedSucessMessage, actualSucessMessage);
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
	}
}

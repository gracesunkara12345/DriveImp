package com.sepaapi.apitests.sprint2;

import java.util.HashMap;
import java.util.Random;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessPatchChangeDirectorOrShareholderStatusTest - CLASS -> HttpPatch
 * Request API. This API is used for change the status of director and
 * shareholder By sending KYBId and status as payLoad.
 * 
 */
public class SepaBusinessPatchChangeDirectorOrShareholderStatusTest extends SepaBase {
	SepaBase sepaBase;
	String businessPatchBusinessOwnerUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	String expectedSucessMessaage = "status update";
	String actualSucessMessaage;
	String actualStatus;
	String expectedStatus = "1";

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessPatchBusinessOwner API URl(HttpPatch)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		businessPatchBusinessOwnerUrl = properties.getProperty("businessPatchBusinessOwner");
	}

	/**
	 * updateStatus() - METHOD -> To execute the HttpPatch
	 * (businessPatchUpdateStatus)API. This API used to update the status director
	 * and shareholder and It returns JsonResponse and We are parsing the obtained
	 * API Response and validating the response based on Message, status &
	 * HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void updateStatus() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness,
				"PatchBusinessOwnerDetails");
		int columnCount = excelUtils.getColumnCount();
		for (int i = 0; i < columnCount; i++) {
			String usersJsonString = excelUtils.DataEntry(i);
			// Json String
			String responseString = sepaRequests.patch(usersJsonString, businessPatchBusinessOwnerUrl);
			responseJson = new JSONObject(responseString);
			actualSucessMessaage = ValidationUtils.getValueByJPath(responseJson, "/message");
			Assert.assertEquals(actualSucessMessaage, expectedSucessMessaage);
			actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
			Assert.assertEquals(actualStatus, expectedStatus);
		}
	}
}
package com.sepaapi.apitests.sprint3;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.apitests.sprint2.SepaSprint2Base;
import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ValidationUtils;

public class SepaGetAccountByApplicantIdTest extends SepaBase {
	SepaBase sepaBase;
	String GetAccountByApplicantIdURL;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String actualStatus;
	String expectedStatus = "1";

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessGetContactDetails API URl(HttpGet)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setUp() throws Exception {
		sepaBase = new SepaBase();
		GetAccountByApplicantIdURL = properties.getProperty("GetAccountByApplicantId");
		GetAccountByApplicantIdURL = GetAccountByApplicantIdURL + SepaSprint2Base.APPLICANT_ID;
	}

	/**
	 * getContactDetailsByApplicantId() - To execute the HTTPGET
	 * API(businessGetContactDetails) It returns contact details based on
	 * apllicantId as closebaleHttpResponse. We are parsing the obtained API
	 * Response and validating the response based on message,status and HTTPStatus
	 * Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void getContactDetailsByApplicantId() throws Exception {
		sepaRequests = new SepaRequests();
		closebaleHttpResponse = sepaRequests.get(GetAccountByApplicantIdURL); // call the API
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		if (responseString.startsWith("[")) {
			JSONArray responseJsonArray = new JSONArray(responseString);
			int count = responseJsonArray.length();
			for (int i = 0; i < count; i++) {
				responseJson = responseJsonArray.getJSONObject(i);
			}
		} else {
			responseJson = new JSONObject(responseString);
			System.out.println("responseJson"+responseJson);
		}
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
	}

}

package com.sepaapi.apitests.sprint3;

import java.util.HashMap;
import java.util.Random;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.apitests.sprint2.SepaSprint2Base;
import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessPatchUpdateStatusTest - CLASS -> HttpPost Request API. This API
 * is used to update the status using BusinessId (change status to
 * submitted,Verified).
 * 
 */
public class SepaPatchUpdateCard extends SepaBase {
	SepaBase sepaBase;
	String PatchUpdateCardUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	String expectedSucessMessaage = "Card deactivated successfuly";
	String actualSucessMessaage;
	String actualStatus;
	String expectedStatus = "1";

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessPatchUpdateStatus API URl(HttpPost)
	 * 
	 * @throws Exception
	 */

	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		PatchUpdateCardUrl = properties.getProperty("PatchUpdateCard");
	}

	/**
	 * updateStatus() - METHOD -> To execute the HttpPost
	 * (businessPatchUpdateStatus)API. This API used to update the status as
	 * verified. and It returns JsonResponse and We are parsing the obtained API
	 * Response and validating the response based on Message, status & HTTPStatus
	 * Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void updateStatus() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestData_Path,
				"UpdatePatchCard");
		// Data Drive from Excel
		String usersJsonString = excelUtils.DataEntry(0);
		System.out.println("usersJsonString"+usersJsonString);
		// Json String
		StringBuffer st = new StringBuffer(usersJsonString);
		st.insert(21, SepaSprint2Base.PAYMENT_CARDS_ID);
		System.out.println("SepaSprint2Base.PAYMENT_CARDS_ID"+SepaSprint2Base.PAYMENT_CARDS_ID);
		String stringSignUp = st.toString();
		requestJSON = new JSONObject(stringSignUp);
		System.out.println("requestJSON"+requestJSON);
		String responseString = sepaRequests.patch(stringSignUp, PatchUpdateCardUrl); // call the API
		responseJson = new JSONObject(responseString);
		System.out.println("responseJson"+responseJson);
		actualSucessMessaage = ValidationUtils.getValueByJPath(responseJson, "/message");
		Assert.assertEquals(actualSucessMessaage, expectedSucessMessaage);
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualStatus, expectedStatus);
	}
}
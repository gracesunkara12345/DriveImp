package com.sepaapi.apitests.sprint3;

import java.io.IOException;
import java.util.Properties;

import org.apache.http.ParseException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ValidationUtils;

public class SepaGetCurrencyExchangeTest extends SepaBase{
	SepaBase sepaBase;
	String GetCurrencyExchangeURL;
	SepaRequests sepaRequests;
	CloseableHttpResponse closeableHttpResponse;
	JSONObject responseJson;
	String actualStatus ;
	String expectedStatus= "1" ;
	@BeforeMethod
	public void setUp()
	{
		sepaBase = new SepaBase();
		GetCurrencyExchangeURL = properties.getProperty("GetCurrencyExchange");
	}
	@Test
	public void GetCurrencyExchange() throws ParseException, IOException, JSONException
	{
		sepaRequests = new SepaRequests();
		closeableHttpResponse = sepaRequests.get(GetCurrencyExchangeURL);
		int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		String responseString = EntityUtils.toString(closeableHttpResponse.getEntity(), "UTF-8");
		if (responseString.startsWith("["))
		{
			JSONArray responseJSONArray  = new JSONArray(responseString);
			int count = responseJSONArray.length();
			for(int i=0 ; i<count; i++)
			{
				responseJson = responseJSONArray.getJSONObject(i);
			}
		}
		else 
		{
			responseJson = new JSONObject(responseString);
			System.out.println("responseJson"+responseJson);
		}
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
		System.out.println("actualStatus"+actualStatus);
	}
}

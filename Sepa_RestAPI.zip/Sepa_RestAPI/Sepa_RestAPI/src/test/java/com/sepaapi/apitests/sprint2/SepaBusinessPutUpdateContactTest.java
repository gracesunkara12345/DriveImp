package com.sepaapi.apitests.sprint2;

import java.util.HashMap;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessPutUpdateContactTest - CLASS -> HttpPut Request API which Update
 * the contact details of respective person. It takes a JSON object as parameter
 * which should Update the contact details an input as Excel sheet and returns a
 * JSON object in response.
 */
public class SepaBusinessPutUpdateContactTest extends SepaBase {
	SepaBase sepaBase;
	String signUpAPIUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	String expectedEmail;
	String businessPutUpdateContactUrl;
	String actualStatus;
	String expectedStatus = "1";
	String expectedSucessMessaage = "Updated successfully";
	String actualSucessMessaage;

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessPutUpdateContact API URl(HttpPut)
	 * 
	 * @throws Exception
	 */

	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		businessPutUpdateContactUrl = properties.getProperty("businessPutUpdateContact");
	}

	/**
	 * UpdateContactDetails() - METHOD -> To execute the HttpPut
	 * API(businessPutUpdateContactUrl) It returns JsonResponse We are Updating the
	 * contact details, and we are validating the obtained API response based on
	 * message ,status & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void updateContactDetails() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness,
				"UpdateContactDetails");
		// Data Drive from Excel
		String usersJsonString = excelUtils.DataEntry(0);
		// Json String
		StringBuffer st = new StringBuffer(usersJsonString);
		st.insert(17, SepaSprint2Base.APPLICANT_ID);
		st.insert(42, SepaSprint2Base.FIRST_NAME);	
		st.insert(84, SepaSprint2Base.LAST_NAME);
		st.insert(104, SepaSprint2Base.EMAIL_ID);
		st.insert(194, SepaSprint2Base.MOBILE_NUMBER);
		String stringSignUp = st.toString();
		requestJSON = new JSONObject(stringSignUp);
		String responseString = sepaRequests.put(stringSignUp, businessPutUpdateContactUrl); // call the API
		responseJson = new JSONObject(responseString);
		// ASSERTIONS...
		actualSucessMessaage = ValidationUtils.getValueByJPath(responseJson, "/message");
		Assert.assertEquals(actualSucessMessaage, expectedSucessMessaage);
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualStatus, expectedStatus);
	}
}

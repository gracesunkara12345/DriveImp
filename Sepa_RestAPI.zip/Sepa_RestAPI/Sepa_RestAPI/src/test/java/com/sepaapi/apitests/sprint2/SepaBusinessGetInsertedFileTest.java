package com.sepaapi.apitests.sprint2;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessGetInsertedFileTest - CLASS -> HttpGET Request API returns
 * inserted file details based on businessId.
 *
 */
public class SepaBusinessGetInsertedFileTest extends SepaBase {
	SepaBase sepaBase;
	String businessGetInsertedFileUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String actualSucessMessage = "Data found";
	String excepctedSucessMessage;
	String actualStatus;
	String expectedStatus = "1";

	/**
	 * setUp() - METHOD -> To load the properties file. Return - businessGetInsertedFile API
	 * URl(HttpGet)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setUp() throws Exception {
		sepaBase = new SepaBase();
		businessGetInsertedFileUrl = properties.getProperty("businessGetInsertedFile");
		businessGetInsertedFileUrl = businessGetInsertedFileUrl + SepaSprint2Base.BUSINESS_ID;
	}

	/**
	 * getInsertedFileDetailsByBusinessId() - METHOD -> To execute the HTTPGET
	 * API(businessGetInsertedFileUrl) It returns file insertion Details
	 * as closebaleHttpResponse. We are parsing the obtained API Response and
	 * validating the response based on status,message &
	 * HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void getInsertedFileDetailsByBusinessId() throws Exception {
		sepaRequests = new SepaRequests();
		closebaleHttpResponse = sepaRequests.get(businessGetInsertedFileUrl); // call the API
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		if (responseString.startsWith("[")) {
			JSONArray responseJsonArray = new JSONArray(responseString);
			int count = responseJsonArray.length();
			for (int i = 0; i < count; i++) {
				responseJson = responseJsonArray.getJSONObject(i);
			}
		} else {
			responseJson = new JSONObject(responseString);
		}
		excepctedSucessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		Assert.assertEquals(excepctedSucessMessage, actualSucessMessage);
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
	}
}

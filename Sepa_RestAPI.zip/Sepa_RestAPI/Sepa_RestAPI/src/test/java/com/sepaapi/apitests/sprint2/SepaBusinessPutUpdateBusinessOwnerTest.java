package com.sepaapi.apitests.sprint2;

import java.util.HashMap;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessPutUpdateBusinessOwnerTest - CLASS -> HttpPut Request API which Update
 * the details of respective person(director/shareholder/other). will update the business owner like director, shareholder, and other.
 */
public class SepaBusinessPutUpdateBusinessOwnerTest extends SepaBase {
	SepaBase sepaBase;
	String signUpAPIUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	String expectedEmail;
	String businessPutBusinessOwnerUrl;
	String actualStatus;
	String expectedStatus = "1";
	String expectedSucessMessaage = "shareholder updated";
	String actualSucessMessaage;
	
	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessPutBusinessOwner API URl(HttpPut)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		businessPutBusinessOwnerUrl = properties.getProperty("businessPutBusinessOwner");
	}

	/**
	 * updateBusinessOwnerDetails() - METHOD -> To execute the HttpPut
	 * API(businessPutUpdateContactUrl) It returns JsonResponse , this API will update the business owner like director, shareholder, and other,
	 * and we are validating the obtained API response based on
	 * message ,status & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void updateBusinessOwnerDetails() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness,"UpdateBusinessOwner");
		int columnCount = excelUtils.getColumnCount();
		
		// Data Drive from Excel
		String usersJsonString = excelUtils.DataEntry(0);
		// Json String
		StringBuffer st = new StringBuffer(usersJsonString);
		st.insert(12, SepaSprint2Base.EMAIL_ID);
		st.insert(52, SepaSprint2Base.FIRST_NAME);
		st.insert(77, SepaSprint2Base.LAST_NAME);
	
		String stringSignUp = st.toString();
		requestJSON = new JSONObject(stringSignUp); 
		String responseString = sepaRequests.put(stringSignUp, businessPutBusinessOwnerUrl); // call the API
		responseJson = new JSONObject(responseString);
		// ASSERTIONS...
		actualSucessMessaage = ValidationUtils.getValueByJPath(responseJson, "/message");
		Assert.assertEquals(actualSucessMessaage, expectedSucessMessaage);
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualStatus, expectedStatus);
	}
}

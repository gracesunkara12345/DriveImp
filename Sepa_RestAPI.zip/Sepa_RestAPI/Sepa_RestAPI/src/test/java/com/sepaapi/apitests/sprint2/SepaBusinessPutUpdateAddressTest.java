package com.sepaapi.apitests.sprint2;

import java.util.HashMap;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessPutUpdateAddressTest - CLASS -> HttpPut Request , This API will
 * able to update the address details of respective person by using ApplicantId.
 */
public class SepaBusinessPutUpdateAddressTest extends SepaBase {
	SepaBase sepaBase;
	String signUpAPIUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	String expectedEmail;
	String businessPutAddressDetailsUrl;
	String actualStatus;
	String expectedStatus = "1";
	String expectedSucessMessaage = "Updated successfully";
	String actualSucessMessaage;

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessPutAddressDetails API URl(HttpPut)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		businessPutAddressDetailsUrl = properties.getProperty("businessPutAddressDetails");
	}

	/**
	 * updateAddressDetails() - METHOD -> To execute the HttpPut
	 * API(businessPutAddressDetails) It returns JsonResponse , This API will able
	 * to update the address details of respective person by using ApplicantId and
	 * we are validating the obtained API response based on message ,status &
	 * HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void updateAddressDetails() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness,
				"UpdateAddressDetails");
		// Data Drive from Excel
		String usersJsonString = excelUtils.DataEntry(0);
		// Json String
		StringBuffer st = new StringBuffer(usersJsonString);
		st.insert(17, SepaSprint2Base.APPLICANT_ID);
		st.insert(64, SepaSprint2Base.COUNTRY_ID);
		String stringSignUp = st.toString();
		requestJSON = new JSONObject(stringSignUp);
		String responseString = sepaRequests.put(stringSignUp, businessPutAddressDetailsUrl); // call the API
		responseJson = new JSONObject(responseString);
		actualSucessMessaage = ValidationUtils.getValueByJPath(responseJson, "/message");
		Assert.assertEquals(actualSucessMessaage, expectedSucessMessaage);
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualStatus, expectedStatus);
	}
}

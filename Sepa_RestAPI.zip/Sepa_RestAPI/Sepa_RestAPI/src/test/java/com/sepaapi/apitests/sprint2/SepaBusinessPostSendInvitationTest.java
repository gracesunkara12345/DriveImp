package com.sepaapi.apitests.sprint2;

import java.util.HashMap;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessPostSetTransactionalModeTest - CLASS -> HttpPost Request , This
 * API will send an invitation link to email provided by Request object.
 */
public class SepaBusinessPostSendInvitationTest extends SepaBase {

	SepaBase sepaBase;
	String businessPostSendInvitationUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String expectedSuccessMesssage = "Link sent to email";
	String actualSuccessMessage;
	String actualStatus;
	String expectedStatus = "1";

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessPostSendInvitation API URl(HttpPost)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		businessPostSendInvitationUrl = properties.getProperty("businessPostSendInvitation");
	}

	/**
	 * sendInvitation() - METHOD -> To execute the HttpPost
	 * API(businessPostSendInvitation) It returns JsonResponse, This API will send
	 * an invitation link to email which are provided by API Request Object and we
	 * are validating the obtained API response based on message ,status &
	 * HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void sendInvitation() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness,
				"PostSendInvitation");
		String usersJsonString = excelUtils.DataEntry(0);
		StringBuffer st = new StringBuffer(usersJsonString);
		st.insert(85, SepaSprint2Base.BUSINESS_ID);
		String stringRegReq = st.toString();
		requestJSON = new JSONObject(stringRegReq);
		closebaleHttpResponse = sepaRequests.post(businessPostSendInvitationUrl, stringRegReq, headerMap);
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		responseJson = new JSONObject(responseString);
		actualSuccessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualSuccessMessage, expectedSuccessMesssage);
		Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
	}
}

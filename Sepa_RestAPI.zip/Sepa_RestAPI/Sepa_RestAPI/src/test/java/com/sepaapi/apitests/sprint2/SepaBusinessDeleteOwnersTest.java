package com.sepaapi.apitests.sprint2;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessDeleteOwnersTest - CLASS -> HttpDELETE Request API which delete particular
 * owner based on businessID.
 *
 */
public class SepaBusinessDeleteOwnersTest extends SepaBase {
	SepaBase sepaBase;
	String businessDeleteOwnerUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	String actualStatus;
	String expectedStatus = "1";
	String RemURL = "/director";
	String expectedSucessMessage = "undefined deleted successfully";
	String actualSucessMessage;

	/**
	 * setUp() - METHOD -> To load the properties file. Return - businessDeleteOwner API
	 * URl(HttpDELETE)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setUp() throws Exception {
		sepaBase = new SepaBase();
		businessDeleteOwnerUrl = properties.getProperty("businessDeleteOwner");
		businessDeleteOwnerUrl = businessDeleteOwnerUrl + SepaSprint2Base.BUSINESS_ID + RemURL;
	}

	/**
	 * deleteDirectorByBusinessID() - METHOD -> To execute the HTTPDELETE
	 * API(businessDeleteOwnerURL) It returns JsonResponse We are parsing the
	 * obtained API Response and validating the response based on message and status
	 * & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void deleteDirectorByBusinessID() throws Exception {
		sepaRequests = new SepaRequests();
		String Respose = sepaRequests.delete(businessDeleteOwnerUrl); // call the API
		if (Respose.startsWith("[")) {
			JSONArray responseJsonArray = new JSONArray(Respose);
			int count = responseJsonArray.length();
			for (int i = 0; i < count; i++) {
				responseJson = responseJsonArray.getJSONObject(i);
			}
		} else {
			responseJson = new JSONObject(Respose);

		}
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
		actualSucessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		Assert.assertEquals(expectedSucessMessage, actualSucessMessage);
	}

}

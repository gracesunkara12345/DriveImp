package com.sepaapi.apitests.sprint2;

import java.util.HashMap;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessPostWithoutKYBTest - CLASS -> HttpPost Request , This API will
 * save company without kyb verification.
 */
public class SepaBusinessPostWithoutKYBTest extends SepaBase {
	SepaBase sepaBase;
	String registrationWithoutKYBUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String expectedSuccessMesssage = "Company Registered successfully.";
	String actualSuccessMessage;
	String actualStatus;
	String expectedStatus = "1";

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * registrationWithoutKYB API URl(HttpPost)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		registrationWithoutKYBUrl = properties.getProperty("registrationWithoutKYB");
	}

	/**
	 * saveCompanyWithoutKYB() - METHOD -> To execute the HttpPut
	 * API(businessPutAddressDetails) It returns JsonResponse , This API will save
	 * company without kyb verification and we are validating the obtained API
	 * response based on message ,status & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void saveCompanyWithoutKYB() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness,
				"WithoutKYBDetails");
		StringBuffer s = new StringBuffer();
		// Data Drive from Excel
		String usersJsonString = excelUtils.DataEntry(0);
		StringBuffer st = new StringBuffer(usersJsonString);
		st.insert(17, SepaSprint2Base.APPLICANT_ID);
		String saveCompanyString = st.toString();
		requestJSON = new JSONObject(saveCompanyString);
		closebaleHttpResponse = sepaRequests.post(registrationWithoutKYBUrl, saveCompanyString, headerMap); // call the
																											// API
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		responseJson = new JSONObject(responseString);
		actualSuccessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualSuccessMessage, expectedSuccessMesssage);
		Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
		SepaSprint2Base.BUSINESS_ID = "";
		SepaSprint2Base.BUSINESS_ID = ValidationUtils.getValueByJPath(responseJson, "/business_id");
	}
}

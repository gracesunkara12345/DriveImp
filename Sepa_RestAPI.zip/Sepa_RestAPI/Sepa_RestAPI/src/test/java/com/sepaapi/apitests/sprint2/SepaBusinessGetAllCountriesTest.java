package com.sepaapi.apitests.sprint2;

import java.util.ArrayList;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessGetAllCountriesTest - CLASS -> HttpGET Request API which
 * retrieves all countries.
 *
 */
public class SepaBusinessGetAllCountriesTest extends SepaBase {

	SepaBase sepaBase;
	String BusinessAllCountriesUrl;
	String countryNameUrl;
	JSONObject responseJson;
	String countryName;
	SepaRequests sepaRequests;
	CloseableHttpResponse closebaleHttpResponse;
	String COUNTRYNAME = "AUSTRIA";

	/**
	 * setUp() - To load the properties file. Return - businessAllCountries API
	 * URl(HttpGet)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setUp() throws Exception {
		sepaBase = new SepaBase();
		BusinessAllCountriesUrl = properties.getProperty("businessAllCountries");
	}

	/**
	 * getAllCountries() - To execute the HTTPGET API(businessAllCountries) It
	 * returns closebaleHttpResponse We are parsing the obtained API Response and
	 * validating the response based on countryName and HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void getAllCountries() throws Exception {
		sepaRequests = new SepaRequests();
		closebaleHttpResponse = sepaRequests.get(BusinessAllCountriesUrl);
		// a. Status Code:
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200, StatusCode_Err_200);
		// b. Json String:
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		ArrayList<String> countryNamesList = new ArrayList<>();
		if (responseString.startsWith("[")) {
			JSONArray responseJsonArray = new JSONArray(responseString);
			int count = responseJsonArray.length();
			for (int i = 0; i < count; i++) {
				responseJson = responseJsonArray.getJSONObject(i);
				countryName = ValidationUtils.getValueByJPath(responseJson, "/country_name");
				countryNamesList.add(countryName);
			}
		} else {
			responseJson = new JSONObject(responseString);
		}
		for (String c : countryNamesList) {
			if (c.contains(COUNTRYNAME)) {
				Assert.assertTrue(c.contains(COUNTRYNAME), "country does not exist");
			}
		}
	}

}

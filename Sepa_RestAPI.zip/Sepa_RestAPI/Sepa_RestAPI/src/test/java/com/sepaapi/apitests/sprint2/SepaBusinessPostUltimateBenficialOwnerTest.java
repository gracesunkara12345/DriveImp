package com.sepaapi.apitests.sprint2;

import java.util.HashMap;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessPostUltimateBenficialOwnerTest - CLASS -> HttpPost Request , This API will
 * save Business owner registration.
 */
public class SepaBusinessPostUltimateBenficialOwnerTest extends SepaBase {
	SepaBase sepaBase;
	String businessUltimateBeneficialOwnerUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String expectedEmail;
	String actualStatus;
	String expectedStatus = "1";
	String actualSuccessMessage;
	String expectedSuccessMesssage = "shareholder Registered successfully.";

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessUltimateBeneficialOwner API URl(HttpPost)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		businessUltimateBeneficialOwnerUrl = properties.getProperty("businessUltimateBeneficialOwner");
	}

	/**
	 * addBeneficialOwner() - METHOD -> To execute the HttpPost
	 * API(businessUltimateBeneficialOwner) It returns JsonResponse , This API will save
	 * business owner registration and we are validating the obtained API
	 * response based on message ,status & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void addBeneficialOwner() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness,
				"UltimateBenificialOwnerDetails");
		// Data Drive from Excel
		String usersJsonString = excelUtils.DataEntry(0);
		// Json String
		StringBuffer st = new StringBuffer(usersJsonString);
		st.insert(16, SepaSprint2Base.FIRST_NAME);
		st.insert(41, SepaSprint2Base.LAST_NAME);
		st.insert(66, SepaSprint2Base.BUSINESS_ID);
		st.insert(80, SepaSprint2Base.EMAIL_ID);
		st.insert(137, SepaSprint2Base.MOBILE_NUMBER);
		String stringdir = st.toString();
		requestJSON = new JSONObject(stringdir);
		closebaleHttpResponse = sepaRequests.post(businessUltimateBeneficialOwnerUrl, stringdir, headerMap); // call
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		responseJson = new JSONObject(responseString);
		String shareholderApplicantId = ValidationUtils.getValueByJPath(responseJson, "/applicantId");
		SepaSprint2Base.SHAREHOLDER_APPLICANT_ID = "";
		SepaSprint2Base.SHAREHOLDER_APPLICANT_ID = shareholderApplicantId;
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		actualSuccessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		Assert.assertEquals(actualSuccessMessage, expectedSuccessMesssage);
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualStatus, expectedStatus);
	}
}

package com.sepaapi.apitests.sprint3;

import java.io.IOException;

import org.apache.http.ParseException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ValidationUtils;

public class SepaGetCheckCardValidationAndTypeTest extends SepaBase{
	
	SepaBase sepaBase;
	SepaRequests sepaRequests;
	String GetCheckCardValidationAndTypeURL;
	CloseableHttpResponse closeableHttpResponse;
	JSONObject responseJSON;
	String actualSuccessMessage = "american-express";
	String expectedSuccessMessage;
	String actualStatus = "1";
	String expectedStatus;
	
	@BeforeMethod
	public void setUp()
	{
		sepaBase = new SepaBase();
		GetCheckCardValidationAndTypeURL = properties.getProperty("GetCheckCardValidationAndType");	
	}
	
	@Test
	public void checkCardValidation() throws ParseException, IOException, JSONException
	{
		sepaRequests = new SepaRequests();
		closeableHttpResponse = sepaRequests.get(GetCheckCardValidationAndTypeURL);
		int statuscode = closeableHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statuscode, RESPONSE_STATUS_CODE_200);
		String resposeString = EntityUtils.toString(closeableHttpResponse.getEntity() , "UTF-8");
		if(resposeString.startsWith("[")) {
			JSONArray responseJSONArray = new JSONArray(resposeString);
			int count = responseJSONArray.length();
			for (int i=0; i<count; i++)
			{
				responseJSON = responseJSONArray.getJSONObject(i);
			}
		}
			else 
			{
				responseJSON = new JSONObject(resposeString);
			}
		expectedSuccessMessage = ValidationUtils.getValueByJPath(responseJSON, "/type");
		Assert.assertEquals(expectedSuccessMessage, actualSuccessMessage);
		expectedStatus = ValidationUtils.getValueByJPath(responseJSON, "/status");
		Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
		}
}

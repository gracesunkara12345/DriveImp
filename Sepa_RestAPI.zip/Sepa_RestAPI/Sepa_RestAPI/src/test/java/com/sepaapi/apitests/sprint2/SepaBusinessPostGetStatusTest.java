package com.sepaapi.apitests.sprint2;

import java.util.HashMap;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessGetInsertStatusTest - CLASS -> HttpGET Request API returns
 * inserted initial status of kybBusiness based on businessId. (get the status
 * of all the required steps. In response we will get "0","1" and "2" which
 * stands for pending, submitted and verified.)
 *
 */

public class SepaBusinessPostGetStatusTest extends SepaBase {

	SepaBase sepaBase;
	String businessGetStatusInsertUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String actualStatus;
	String expectedStatus = "1";

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessPostGetStatus API URl(HttpPost)
	 * 
	 * @throws Exception
	 */

	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		businessGetStatusInsertUrl = properties.getProperty("businessPostGetStatus");
	}

	/**
	 * getStatus() - METHOD -> To execute the HttpPost API(businessGetStatusInsert)
	 * It returns file insertion status as closebaleHttpResponse. We are parsing the
	 * obtained API Response and validating the response based on status,message &
	 * HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */

	@Test
	public void getStatus() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness, "GetStatus");
		String usersJsonString = excelUtils.DataEntry(0);
		StringBuffer st = new StringBuffer(usersJsonString);
		st.insert(16, SepaSprint2Base.BUSINESS_ID);
		String stringRegReq = st.toString();
		requestJSON = new JSONObject(stringRegReq);
		closebaleHttpResponse = sepaRequests.post(businessGetStatusInsertUrl, stringRegReq, headerMap);
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		responseJson = new JSONObject(responseString);
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
	}
}

package com.sepaapi.apitests.sprint2;

import java.util.HashMap;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessPostInsertStatusTest - CLASS -> HttpPost Request , This API used
 * to insert initial status as "pending" for all the status in kyb_business
 * table.
 */
public class SepaBusinessPostInsertStatusTest extends SepaBase {

	SepaBase sepaBase;
	String businessPostStatusInsertUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String expectedSuccessMesssage = "Status inserted successfully.";
	String actualSuccessMessage;
	String actualStatus;
	String expectedStatus = "1";

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessPostStatusInsert API URl(HttpPost)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		businessPostStatusInsertUrl = properties.getProperty("businessPostStatusInsert");
	}

	/**
	 * insertStatus() - METHOD -> To execute the HttpPost API(businessKycEntry) It
	 * returns JsonResponse, This API will insert initial status as "pending" for
	 * all the status in kyb_business table. which are provided by API Request
	 * Object and we are validating the obtained API response based on message
	 * ,status & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void insertStatus() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness, "InsertStatus");
		int columnCount = excelUtils.getColumnCount();
		String usersJsonString = excelUtils.DataEntry(0);
		StringBuffer st = new StringBuffer(usersJsonString);
		st.insert(16, SepaSprint2Base.BUSINESS_ID);
		String stringRegReq = st.toString();
		requestJSON = new JSONObject(stringRegReq);
		closebaleHttpResponse = sepaRequests.post(businessPostStatusInsertUrl, stringRegReq, headerMap); // API
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		responseJson = new JSONObject(responseString);
		actualSuccessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualSuccessMessage, expectedSuccessMesssage);
		Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
	}
}

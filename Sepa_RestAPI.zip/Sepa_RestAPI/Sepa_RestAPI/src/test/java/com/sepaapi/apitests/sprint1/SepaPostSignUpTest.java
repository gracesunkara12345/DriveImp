package com.sepaapi.apitests.sprint1;

import java.util.HashMap;
import java.util.Random;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
* SepaPostSignUpTest - HttpPost Request API which Posts User Details.
*/
public class SepaPostSignUpTest extends SepaBase {
	SepaBase sepaBase;
	String signUpAPIUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String expectedEmail;
	
	/**
	 * setUp() - To load the properties file.
	 * @throws Exception
	 */

	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		signUpAPIUrl = properties.getProperty("signUpUrl");
	}

	/**
	 * postSignUp() - To execute the HTTPPOST API(SignUp)
	 * We are parsing the obtained API Response and validating the response based on Email and HTTPStatus Codes.
	 * @throws Exception
	 */
	@Test
	public void userSignUp() throws Exception {
		
		  sepaRequests = new SepaRequests();
		  
		  HashMap<String, String> headerMap = new HashMap<String, String>();
		  headerMap.put("Content-Type", "application/json");
		  
		  ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPath, "SignUp"); 
		  int columnCount =excelUtils.getColumnCount();		
		 //Mobile Number generator
		  Random objGenerator = new Random(); 
		  StringBuffer s = new StringBuffer();
		  String str1 ="";
		  
		  for (int iCount = 0; iCount< 7;iCount++)
		  {
			  int randomNumber = objGenerator.nextInt(9); 
			  str1 =  String.valueOf(randomNumber);
			  s.append(str1);
		  }
		  String mobile="987"+s;
		  
		  //Random firstName ,LastName ,Email and Password
		  String firstName=RandomStringUtils.randomAlphabetic(8);
		  String lastName=RandomStringUtils.randomAlphabetic(8); 
		  String email=RandomStringUtils.randomAlphabetic(8); 
		  String password=RandomStringUtils.randomAlphabetic(8);
		 
		  //Data Drive from Excel
		  String usersJsonString = excelUtils.DataEntry(0);
		  //Json String 
		  StringBuffer st = new StringBuffer(usersJsonString); 
		  System.out.println(usersJsonString);
		  st.insert(66, firstName);
		  st.insert(110,lastName); 
		  st.insert(135, email);
		  st.insert(219, mobile);
		  st.insert(267,"123456");
		  st.insert(399, password);
		  st.insert(426, "1234");
		 
		  String stringSignUp=st.toString();		 
		  requestJSON = new JSONObject(stringSignUp);
		  System.out.println("stringSignUp"+stringSignUp);
		  String actualEmail =ValidationUtils.getValueByJPath(requestJSON, "/email");
		  closebaleHttpResponse = sepaRequests.post(signUpAPIUrl, stringSignUp,headerMap); // call the API
		
		  int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		  Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		  String responseString =  EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		  responseJson = new JSONObject(responseString);
		  System.out.println(responseJson);
		  expectedEmail =ValidationUtils.getValueByJPath(responseJson, "/userInfo/email");  
		  Assert.assertEquals(actualEmail, expectedEmail);
}
}
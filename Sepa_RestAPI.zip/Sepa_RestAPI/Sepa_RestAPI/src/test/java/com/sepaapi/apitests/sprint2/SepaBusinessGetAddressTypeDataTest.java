package com.sepaapi.apitests.sprint2;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessGetAddressTypeDataTest - CLASS -> HttpGET Request API which
 * retrieves Address Types.
 *
 */
public class SepaBusinessGetAddressTypeDataTest extends SepaBase {
	SepaBase sepaBase;
	String businessGetgetthedataofaddresstypesUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String address_type_id;
	String actualSucessMessage = "address_type fetched successfully.";
	String excepctedSucessMessage;
	String actualStatus;
	String expectedStatus = "1";

	/**
	 * setUp() -Method-> To load the properties file. Return -
	 * businessGetgetthedataofaddresstypes API URl(HttpGet)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setUp() throws Exception {
		sepaBase = new SepaBase();
		businessGetgetthedataofaddresstypesUrl = properties.getProperty("businessGetgetthedataofaddresstypes");
	}

	/**
	 * getAddressTypes() - To execute the HTTPGET
	 * API(businessGetgetthedataofaddresstypes) It returns closebaleHttpResponse. We
	 * are parsing the obtained API Response and validating the response based on
	 * success Message,status & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void getAddressTypes() throws Exception {
		sepaRequests = new SepaRequests();
		closebaleHttpResponse = sepaRequests.get(businessGetgetthedataofaddresstypesUrl); // call the API
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");

		if (responseString.startsWith("[")) {
			JSONArray responseJsonArray = new JSONArray(responseString);
			int count = responseJsonArray.length();
			for (int i = 0; i < count; i++) {
				responseJson = responseJsonArray.getJSONObject(i);
				address_type_id = ValidationUtils.getValueByJPath(responseJson, "address_type_id");
				Assert.assertEquals(Integer.parseInt(address_type_id), i + 1);
			}
		} else {
			responseJson = new JSONObject(responseString);
		}
		excepctedSucessMessage = ValidationUtils.getValueByJPath(responseJson, "/message/success");
		Assert.assertEquals(excepctedSucessMessage, actualSucessMessage);
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
	}

}

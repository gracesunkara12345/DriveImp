package com.sepaapi.apitests.sprint1;

import java.util.HashMap;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;
/**
* SepaPostLoginTest - HttpPost Request API which Posts User Details to check Login.
*/
public class SepaPostLoginTest extends SepaBase {

	SepaBase sepaBase;
	String loginAPIUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String email;
	String expectedSuccessMesssage = "login successfull";
	String actualSuccessMessage;
	String actualStatus;
	String expectedStatus = "1";
	String expectedEmail;
	
	/**
	 * setUp() - To load the properties file.
	 * @throws Exception
	 */
	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		loginAPIUrl = properties.getProperty("loginUrl");
	}


	/**
	 * loginPostRequest() - To execute the HTTPPOST API(LoginAPI)
	 * @param we are sending UserDetails(Email,mpin,account-type) as JSON object to API to check the login response
	 * We are parsing the obtained API Response and validating the response based on Email and HTTPStatus Codes as well as status.
	 * @throws Exception
	 */
	@Test
	public void loginPostRequest() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPath,
				"LoginDetails");
		int columnCount = excelUtils.getColumnCount();
		for (int i = 0; i < columnCount; i++) {
			String usersJsonString = excelUtils.DataEntry(i);
			requestJSON = new JSONObject(usersJsonString);
			String actualEmail = ValidationUtils.getValueByJPath(requestJSON, "/email");
			closebaleHttpResponse = sepaRequests.post(loginAPIUrl, usersJsonString, headerMap); // call the API
			int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
			Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200, StatusCode_Err_200);
			String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
			responseJson = new JSONObject(responseString);
			expectedEmail = ValidationUtils.getValueByJPath(responseJson, "/userInfo/email");
			actualSuccessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
			actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
			Assert.assertEquals(actualSuccessMessage, expectedSuccessMesssage);
			Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
			Assert.assertEquals(actualEmail, expectedEmail);
		}

	}

}

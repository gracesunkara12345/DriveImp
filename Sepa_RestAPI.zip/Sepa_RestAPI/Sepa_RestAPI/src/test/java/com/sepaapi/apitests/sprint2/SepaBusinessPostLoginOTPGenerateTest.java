package com.sepaapi.apitests.sprint2;

import java.util.HashMap;
import java.util.Random;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessPostLoginOTPGenerateTest - CLASS -> HttpPost Request ,
 *  This API used for Generating Otp to send user mobile for validation.
 */
public class SepaBusinessPostLoginOTPGenerateTest extends SepaBase {
	SepaBase sepaBase;
	String businessloginOTPUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String expectedEmail;
	String businessUserSignUpUrl;
	String actualStatus;
	String expectedStatus = "1";
	String actualSuccessMessage;
	String expectedSuccessMesssage = "Message Sent With Varification OTP";

	/**
	 * setUp() - METHOD -> To load the properties file. Return - businessloginOTP
	 * API URl(HttpPost)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		businessloginOTPUrl = properties.getProperty("businessloginOTP");
	}

	/**
	 * generateOTPForLogin() - METHOD -> To execute the HttpPost API(businessloginOTP) It
	 * returns JsonResponse, This API will will generate an OTP which is sent to mobile. which are provided by API Request Object and we
	 * are validating the obtained API response based on message ,status &
	 * HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void generateOTPForLogin() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness,"loginOTPGenerationDetails");
		String usersJsonString = excelUtils.DataEntry(0);
				// Json String
				StringBuffer st = new StringBuffer(usersJsonString);
			
				st.insert(19, SepaSprint2Base.MOBILE_NUMBER);
				
				String stringOTPgeneration = st.toString();
				requestJSON = new JSONObject(stringOTPgeneration);
				closebaleHttpResponse = sepaRequests.post(businessloginOTPUrl, stringOTPgeneration, headerMap); // call the API
				int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
				Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
				String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
				responseJson = new JSONObject(responseString);
				
				actualSuccessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
				actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
				Assert.assertEquals(actualSuccessMessage, expectedSuccessMesssage);
				Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
}
}
package com.sepaapi.apitests.sprint1;

import java.util.HashMap;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaGetCountryByCountryNameAPITest - HttpGet Request API which retrieves each
 * Countries based on Country Name.
 *
 */
public class SepaGetCountryByCountryNameAPITest extends SepaBase {

	SepaBase sepaBase;
	String allCountriesUrl;
	String countryNameUrl;
	String countryName;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	String actualcountryName;
	CloseableHttpResponse closebaleHttpResponse;

	/**
	 * setUp() - To load the properties file. Return - getCountryByCountryName API
	 * URl(HttpGet)
	 * @throws Exception
	 */
	@BeforeMethod
	public void setUp() throws Exception {
		sepaBase = new SepaBase();
		allCountriesUrl = properties.getProperty("countryNameUrl");
	}

	/**
	 * getAllCountriesAPI() - To execute the HTTPGET API(CountryURL) It returns
	 * closebaleHttpResponse We are looping all countries based on specific
	 * countryName and getting the closebaleHttpResponse. We are parsing the
	 * obtained API Response and validating the response based on countryName and
	 * HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void getAllCountryByCountryName() throws Exception {
		sepaRequests = new SepaRequests();

		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPath,"CountryNames");
		int columnCount = excelUtils.getColumnCount();
		for (int i = 0; i < columnCount; i++) {
			countryName = excelUtils.DataEntry(i);
			String usersJsonStringURL = allCountriesUrl + countryName;
			closebaleHttpResponse = sepaRequests.get(usersJsonStringURL); // call the API
			int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
			Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
			String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
			if (responseString.startsWith("[")) {
				JSONArray responseJsonArray = new JSONArray(responseString);
				responseJson = responseJsonArray.getJSONObject(0);
			} else {
				responseJson = new JSONObject(responseString);
			}
			actualcountryName = ValidationUtils.getValueByJPath(responseJson, "/country_name");

			if (actualcountryName.endsWith(" ")) {

				Assert.assertEquals(actualcountryName, countryName + " ");

			} else if (actualcountryName.endsWith("")) {
				Assert.assertEquals(actualcountryName, countryName);
			}
		}

	}
}

package com.sepaapi.apitests.sprint2;

import java.util.HashMap;
import java.util.Random;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessPatchBusinessSectorDetailsTest - CLASS -> HttpPatch Request API.
 * This API is used This API is to update business_sector_details table data. We
 * need to pass column name, value as well as the business_id as payLoad .
 * 
 */
public class SepaBusinessPatchBusinessSectorDetailsTest extends SepaBase {
	SepaBase sepaBase;
	String businessPatchSectorDetailsUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	String expectedSucessMessaage = "Data updated successfully";
	String actualSucessMessaage;
	String actualStatus;
	String expectedStatus = "1";

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessPatchSectorDetails API URl(HttpPatch)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		businessPatchSectorDetailsUrl = properties.getProperty("businessPatchSectorDetails");
	}

	/**
	 * sectorDetailsPatch() - METHOD -> To execute the HttpPatch
	 * (businessPatchUpdateStatus)API. This API used to update
	 * business_sector_details table data. We need to pass column name, value as
	 * well as the business_id as payLoad and It returns JsonResponse and We are
	 * parsing the obtained API Response and validating the response based on
	 * Message, status & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void sectorDetailsPatch() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness,
				"PatchBusinessSectorDetatils");
		// Data Drive from Excel
		String usersJsonString = excelUtils.DataEntry(0);
		// Json String
		StringBuffer st = new StringBuffer(usersJsonString);
		st.insert(17, SepaSprint2Base.BUSINESS_ID);
		String stringSignUp = st.toString();
		requestJSON = new JSONObject(stringSignUp);
		String responseString = sepaRequests.patch(stringSignUp, businessPatchSectorDetailsUrl); // call the API
		responseJson = new JSONObject(responseString);
		actualSucessMessaage = ValidationUtils.getValueByJPath(responseJson, "/message");
		Assert.assertEquals(actualSucessMessaage, expectedSucessMessaage);
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualStatus, expectedStatus);
	}
}
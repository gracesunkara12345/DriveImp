package com.sepaapi.apitests.sprint2;

import java.util.HashMap;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessPostSetTransactionVolumeTest - CLASS -> HttpPost Request , This
 * API used for the store the transactional information which it will describes
 * about monthly volume of transfer and number of payments per month .
 */
public class SepaBusinessPostSetTransactionVolumeTest extends SepaBase {

	SepaBase sepaBase;
	String businessPostSetTransactionVolumeUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String expectedSuccessMesssage = "Data stored successfully";
	String actualSuccessMessage;
	String actualStatus;
	String expectedStatus = "1";

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessPostSetTransactionVolume API URl(HttpPost)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		businessPostSetTransactionVolumeUrl = properties.getProperty("businessPostSetTransactionVolume");
	}

	/**
	 * setBusinessTransactionVolume() - METHOD -> To execute the HttpPost
	 * API(businessPostSetTransactionVolume) It returns JsonResponse, This API will
	 * save business owner registration and we are validating the obtained API
	 * response based on message ,status & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void setBusinessTransactionVolume() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness,
				"SetTransactionVolumeDetails");
		int columnCount = excelUtils.getColumnCount();
		for (int i = 0; i < columnCount; i++) {
			String usersJsonString = excelUtils.DataEntry(i);
			requestJSON = new JSONObject(usersJsonString);
			closebaleHttpResponse = sepaRequests.post(businessPostSetTransactionVolumeUrl, usersJsonString, headerMap);
			int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
			Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
			String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
			responseJson = new JSONObject(responseString);
			actualSuccessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
			actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
			Assert.assertEquals(actualSuccessMessage, expectedSuccessMesssage);
			Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
		}
	}
}

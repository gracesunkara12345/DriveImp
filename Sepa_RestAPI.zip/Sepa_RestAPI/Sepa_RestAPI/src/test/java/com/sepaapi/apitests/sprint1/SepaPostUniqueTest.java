package com.sepaapi.apitests.sprint1;

import java.util.HashMap;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
* SepaPostUniqueTest - HttpPost Request API which Posts Email and Checks Whether given Email Exits or Not.
*/
public class SepaPostUniqueTest extends SepaBase {
	SepaBase sepaBase;
	String uniquePostUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String email;
	String expectedSuccessMesssage = "email does not exist.";
	String actualSuccessMessage;
	String actualStatus;
	String expectedStatus = "0";

	/**
	 * setUp() - To load the properties file.
	 * @throws Exception
	 */
	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		uniquePostUrl = properties.getProperty("uniqueUrl");
	}

	/**
	 * checkEmailExits() - To execute the HTTPPOST API(UniqueUrl)
	 * We are parsing the obtained API Response and validating the response based on Actual Message and HTTPStatus Codes.
	 * @throws Exception
	 */
	@Test
	public void checkEmailExists() throws Exception {
		sepaRequests = new SepaRequests();

		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");

		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPath,
				"UniqueUrlSheet");
		int columnCount = excelUtils.getColumnCount();

		for (int i = 0; i < columnCount; i++) {
			String usersJsonString = excelUtils.DataEntry(i);
			requestJSON = new JSONObject(usersJsonString);
			String actualEmail = ValidationUtils.getValueByJPath(requestJSON, "/emailORmobile");
			closebaleHttpResponse = sepaRequests.post(uniquePostUrl, usersJsonString, headerMap); // call the API
			int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
			Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
			String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
			responseJson = new JSONObject(responseString);
			actualSuccessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
			actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
			Assert.assertEquals(actualSuccessMessage, expectedSuccessMesssage);
			Assert.assertEquals(actualStatus, expectedStatus);
		}
	}
}

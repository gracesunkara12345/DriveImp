package com.sepaapi.apitests.sprint3;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.apitests.sprint2.SepaSprint2Base;
import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessGetCountryByNameTest - CLASS -> HttpGET Request API which
 * retrieves contactDetails based on countryName.
 *
 */
public class SepaGetCountryByNameTest extends SepaBase {
	
	SepaBase sepaBase;
	String countryNameUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	String actualcountryName;
	CloseableHttpResponse closebaleHttpResponse;

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessGetContactDetails businessCountryNameUrl URl(HttpGet)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setUp() throws Exception {
		sepaBase = new SepaBase();
		countryNameUrl = properties.getProperty("businessCountryNameUrl");
	}

	/**
	 * getCountryByCountryName() - To execute the HTTPGET
	 * API(businessCountryNameUrl) It returns country details based on
	 * CountryName as closebaleHttpResponse. We are parsing the obtained API
	 * Response and validating the response based on CountryName,country_id and HTTPStatus
	 * Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void getCountryByCountryName() throws Exception {
		sepaRequests = new SepaRequests();
		String usersJsonStringURL = countryNameUrl;
		closebaleHttpResponse = sepaRequests.get(usersJsonStringURL); // call the API
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		if (responseString.startsWith("[")) {
			JSONArray responseJsonArray = new JSONArray(responseString);
			responseJson = responseJsonArray.getJSONObject(0);
		} else {
			responseJson = new JSONObject(responseString);
		}
		actualcountryName = ValidationUtils.getValueByJPath(responseJson, "/country_name");
		SepaSprint2Base.COUNTRY_ID = "";
		SepaSprint2Base.COUNTRY_ID = ValidationUtils.getValueByJPath(responseJson, "/country_id");
	}
}

package com.sepaapi.apitests.sprint2;

/**
 * SepaSprint2Base - class
 * SepaSprint2Base class used in different testCases using extends keyword 
 * To initialize the constants and use as global variables throughout the end to end flow which will use as key values for APIs request.
 */
public class SepaSprint2Base {
	public static String APPLICANT_ID;
	public static String BUSINESS_ID;
	public static String COUNTRY_ID;
	public static String EMAIL_ID;
	public static String PASSWORD;
	public static String MOBILE_NUMBER;
	public static String BUSINESS_SECTOR_TYPE = "2";
	public static String FIRST_NAME;
	public static String LAST_NAME;
	public static String SHAREHOLDER_APPLICANT_ID;
	public static String CONTACT_ID;
	public static String PAYMENT_CARDS_ID;
}

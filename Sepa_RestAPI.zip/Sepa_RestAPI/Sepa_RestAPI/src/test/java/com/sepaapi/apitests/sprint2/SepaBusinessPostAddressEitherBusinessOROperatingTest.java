package com.sepaapi.apitests.sprint2;

import java.util.HashMap;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessPostAddressEitherBusinessOROperatingTest - CLASS -> HttpPost
 * Request API. This API used to update the business address details i..e either
 * Business Or Operating address.
 * 
 */
public class SepaBusinessPostAddressEitherBusinessOROperatingTest extends SepaBase {
	SepaBase sepaBase;
	String businessPostAddressEitherBusinessOROperatingUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String email;
	String expectedSuccessMesssage = "Business Address Updated successfully";
	String actualSuccessMessage;
	String actualStatus;
	String expectedStatus = "1";
	String expectedEmail;

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessPostAddressEitherBusinessOROperating API URl(HttpPost)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		businessPostAddressEitherBusinessOROperatingUrl = properties
				.getProperty("businessPostAddressEitherBusinessOROperating");
	}

	/**
	 * updateAddressEitherBusinessOrOperating() - METHOD -> To execute the HttpPost
	 * (businessPostAddressEitherBusinessOROperating)API. TThis API used to update
	 * the business address details i..e either Business Or Operating address. and
	 * It returns JsonResponse and We are parsing the obtained API Response and
	 * validating the response based on Message, status & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void updateAddressEitherBusinessOrOperating() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness,
				"AddresEitherBusinessOROperating");
		// Data Drive from Excel
		String usersJsonString = excelUtils.DataEntry(0);
		// Json String
		StringBuffer stringBuffer = new StringBuffer(usersJsonString);
		stringBuffer.insert(17, SepaSprint2Base.APPLICANT_ID);
		stringBuffer.insert(62, SepaSprint2Base.COUNTRY_ID);
		String stringReq = stringBuffer.toString();
		requestJSON = new JSONObject(stringReq);
		closebaleHttpResponse = sepaRequests.post(businessPostAddressEitherBusinessOROperatingUrl, stringReq,headerMap); // call the API
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		responseJson = new JSONObject(responseString);
		actualSuccessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualSuccessMessage, expectedSuccessMesssage);
		Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
	}
}
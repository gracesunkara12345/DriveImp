package com.sepaapi.apitests.sprint2;

import java.util.HashMap;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessPostAddShareHolderTest - CLASS -> HttpPost Request API. This API
 * is used to register Shareholder using BusinessId and all basic details as
 * Pay_Load.
 * 
 */
public class SepaBusinessPostAddShareHolderTest extends SepaBase {
	SepaBase sepaBase;
	String businessPostAddDirectorOrShareHolderUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String expectedEmail;
	String actualStatus;
	String expectedStatus = "1";
	String actualSuccessMessage;
	String expectedSuccessMesssage = "shareholder added";

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessPostAddressEitherBusinessOROperating API URl(HttpPost)
	 * 
	 * @throws Exception
	 */

	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		businessPostAddDirectorOrShareHolderUrl = properties.getProperty("businessPostAddDirectorOrShareHolder");
	}

	/**
	 * updateAddressEitherBusinessOrOperating() - METHOD -> To execute the HttpPost
	 * (businessPostAddressEitherBusinessOROperating)API. This API used to add
	 * the shareholder to the  company. and
	 * It returns JsonResponse and We are parsing the obtained API Response and
	 * validating the response based on Message, status & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void addShareHolder() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness,
				"addDirectorORShareholder");
		// Random firstName ,LastName ,Email and Password
		String firstName = RandomStringUtils.randomAlphabetic(8);
		String lastName = RandomStringUtils.randomAlphabetic(8);
		String email = RandomStringUtils.randomAlphabetic(8);
		// Data Drive from Excel
		String usersJsonString = excelUtils.DataEntry(1);
		// Json String
		StringBuffer st = new StringBuffer(usersJsonString);
		st.insert(26, firstName);
		st.insert(50, lastName);
		st.insert(74, email);
		st.insert(189, SepaSprint2Base.BUSINESS_ID);
		String stringdir = st.toString();
		requestJSON = new JSONObject(stringdir);
		closebaleHttpResponse = sepaRequests.post(businessPostAddDirectorOrShareHolderUrl, stringdir, headerMap);
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		responseJson = new JSONObject(responseString);
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		actualSuccessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		Assert.assertEquals(actualSuccessMessage, expectedSuccessMesssage);
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualStatus, expectedStatus);
	}
}

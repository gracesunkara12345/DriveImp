package com.sepaapi.apitests.sprint3;

import java.util.HashMap;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.apitests.sprint2.SepaSprint2Base;
import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessUserPostSignUpTest - CLASS -> HttpPost Request API which Posts
 * Business UserData to register. This API is to use for USERDATA registration
 * into table in data base. It takes a JSON object as parameter which should
 * have 13 properties mentioned in input Excel sheet and returns a JSON object
 * in response.
 */
public class SepaUserPostSignUpTest extends SepaBase {
	SepaBase sepaBase;
	String signUpAPIUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String expectedEmail;
	String businessUserSignUpUrl;
	String actualStatus;
	String expectedStatus = "1";
	String actualSuccessMessage;
	String expectedSuccessMesssage = "registratiton successfully";

	/**
	 * setUp() - METHOD -> To load the properties file. Return - businessUserSignUp
	 * API URl(HttpPost)
	 * @throws Exception
	 */
	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		businessUserSignUpUrl = properties.getProperty("businessUserSignUp");
	}

	/**
	 * BusinessUserSignUp() - METHOD -> To execute the HttpPost
	 * API(businessUserSignUpURL) It returns JsonResponse We are parsing the
	 * obtained API Response and validating the response based on
	 * ApplicantId,email,message and status & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void BusinessUserSignUp() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness,
				"BusinessUserSignUpDetails");
		// Mobile Number generator
		Random objGenerator = new Random();
		StringBuffer s = new StringBuffer();
		String str1 = "";
		for (int iCount = 0; iCount < 7; iCount++) {
			int randomNumber = objGenerator.nextInt(9);
			str1 = String.valueOf(randomNumber);
			s.append(str1);
		}
		String mobile = "987" + s;
		// Random firstName ,LastName ,Email and Password
		String firstName = RandomStringUtils.randomAlphabetic(8);
		String lastName = RandomStringUtils.randomAlphabetic(8);
		String email = RandomStringUtils.randomAlphabetic(8);
		String password = RandomStringUtils.randomAlphabetic(8);
		// Data Drive from Excel
		String usersJsonString = excelUtils.DataEntry(0);
		// Json String
		StringBuffer st = new StringBuffer(usersJsonString);
		st.insert(66, firstName);
		st.insert(110, lastName);
		st.insert(135, email);
		st.insert(219, mobile);
		st.insert(247, SepaSprint2Base.COUNTRY_ID);
		st.insert(402, password);
		String stringSignUp = st.toString();
		requestJSON = new JSONObject(stringSignUp);
		System.out.println("requestJSON************"+requestJSON);
		String actualEmail = ValidationUtils.getValueByJPath(requestJSON, "/email");
		String basefirstName = ValidationUtils.getValueByJPath(requestJSON, "/first_name");
		String baselastName = ValidationUtils.getValueByJPath(requestJSON, "/last_name");
		// Setting values for global variables which will use as inputs for rest of the
		// APIs Request parameters.
		SepaSprint2Base.FIRST_NAME = "";
		SepaSprint2Base.FIRST_NAME = basefirstName;
		SepaSprint2Base.LAST_NAME = "";
		SepaSprint2Base.LAST_NAME = baselastName;
		SepaSprint2Base.EMAIL_ID = "";
		SepaSprint2Base.EMAIL_ID = actualEmail;
		SepaSprint2Base.PASSWORD = "";
		SepaSprint2Base.PASSWORD = ValidationUtils.getValueByJPath(requestJSON, "/password");
		SepaSprint2Base.MOBILE_NUMBER = "";
		SepaSprint2Base.MOBILE_NUMBER = ValidationUtils.getValueByJPath(requestJSON, "/mobile");

		closebaleHttpResponse = sepaRequests.post(businessUserSignUpUrl, stringSignUp, headerMap); // call the API
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		responseJson = new JSONObject(responseString);
		System.out.println("responseString+++++++"+responseString);
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		// ASSERTIONS....
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		expectedEmail = ValidationUtils.getValueByJPath(responseJson, "/userInfo/email");
		Assert.assertEquals(actualEmail, expectedEmail);
		actualSuccessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		Assert.assertEquals(actualSuccessMessage, expectedSuccessMesssage);
		SepaSprint2Base.APPLICANT_ID = ValidationUtils.getValueByJPath(responseJson, "/userInfo/applicant_id");
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualStatus, expectedStatus);
	}
}

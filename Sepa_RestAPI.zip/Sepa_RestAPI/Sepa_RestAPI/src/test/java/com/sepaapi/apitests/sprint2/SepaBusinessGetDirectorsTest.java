package com.sepaapi.apitests.sprint2;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessGetDirectorsTest - CLASS -> HttpGET Request API which accepts input as businessID and
 * retrieves director details.
 *
 */
public class SepaBusinessGetDirectorsTest extends SepaBase {
	SepaBase sepaBase;
	String businessGetDirectorsUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	JSONObject responseJson1;
	String businessOwner1;
	CloseableHttpResponse closebaleHttpResponse;
	String actualStatus;
	String expectedStatus = "1";
	String actualSucessMessage ;
	String expectedSucesMessage = "Fetched business owners";

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessDirectorDetails. businessGetDirectors
	 * URl(HttpGet)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setUp() throws Exception {
		sepaBase = new SepaBase();
		businessGetDirectorsUrl = properties.getProperty("businessGetDirectors");
		businessGetDirectorsUrl = businessGetDirectorsUrl + SepaSprint2Base.BUSINESS_ID;
	}

	/**
	 * getDirectorDetailsByBusinessId() - METHOD -> To execute the HTTPGET
	 * API(businessGetDirectorsUrl) It returns BusinessDirector Details
	 * as closebaleHttpResponse. We are parsing the obtained API Response and
	 * validating the response based on status,message & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void getDirectorDetailsByBusinessId() throws Exception {
		sepaRequests = new SepaRequests();
		closebaleHttpResponse = sepaRequests.get(businessGetDirectorsUrl); // call the API
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		if (responseString.startsWith("[")) {
			JSONArray responseJsonArray = new JSONArray(responseString);
			int count = responseJsonArray.length();
			for (int i = 0; i < count; i++) {
				responseJson = responseJsonArray.getJSONObject(i);
			}
		} else {
			responseJson = new JSONObject(responseString);
		}
		String businessOwner=ValidationUtils.getValueByJPath(responseJson, "/businessOwners");
		if(businessOwner.startsWith("[")) {
			JSONArray responseJsonArray1 = new JSONArray(businessOwner);
			int count = responseJsonArray1.length();
			for (int i = 0; i < count; i++) {
				responseJson1 = responseJsonArray1.getJSONObject(i);
				businessOwner1=ValidationUtils.getValueByJPath(responseJson1, "/contact_id");
			}
		}
		SepaSprint2Base.CONTACT_ID = "";
		SepaSprint2Base.CONTACT_ID =businessOwner1;
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
		actualSucessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		Assert.assertEquals(actualSucessMessage,expectedSucesMessage);
	}

}

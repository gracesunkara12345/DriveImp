package com.sepaapi.apitests.sprint2;

import java.util.HashMap;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessPostChangePasswordTest - CLASS -> HttpPost Request API It is use
 * for change password after post login(We are providing pay load as Old
 * password,new Password, ApplicantID).
 */
public class SepaBusinessPostChangePasswordTest extends SepaBase {
	SepaBase sepaBase;
	String businessChangePasswordUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String expectedSuccessMesssage = "Password changed successfully";
	String actualSuccessMessage;
	String actualStatus;
	String expectedStatus = "1";

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * checkBusinessSectorDetailsAllReadyRegisteredORNot API URl(HttpPost)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		businessChangePasswordUrl = properties.getProperty("businessChangePassword");
	}

	/**
	 * changePassword() - METHOD -> To execute the HttpPost
	 * API(businessChangePassword) API It is use for change password after post
	 * login(We are providing pay load as Old password,new Password, ApplicantID).
	 * It returns JsonResponse and We are parsing the obtained API Response and
	 * validating the response based on business_sector , status & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void changePassword() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness, "ChangePassword");
		// Data Drive from Excel
		String usersJsonString = excelUtils.DataEntry(0);
		String newpassword = RandomStringUtils.randomAlphabetic(8);
		// Json String
		StringBuffer stringBuffer = new StringBuffer(usersJsonString);
		stringBuffer.insert(17, SepaSprint2Base.PASSWORD);
		stringBuffer.insert(43, newpassword);
		stringBuffer.insert(69, SepaSprint2Base.APPLICANT_ID);
		String stringReq = stringBuffer.toString();
		requestJSON = new JSONObject(stringReq);
		closebaleHttpResponse = sepaRequests.post(businessChangePasswordUrl, stringReq, headerMap); // call the API
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		responseJson = new JSONObject(responseString);
		actualSuccessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualSuccessMessage, expectedSuccessMesssage);
		Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
	}
}

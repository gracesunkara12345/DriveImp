package com.sepaapi.apitests.sprint2;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessGetAddressDetailsTest - CLASS -> HttpGET Request API which
 * retrieves AddressDetails based on APPLICANT_ID.
 *
 */
public class SepaBusinessGetAddressDetailsTest extends SepaBase {
	SepaBase sepaBase;
	String businessGetAddressDetailsUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String actualSucessMessage = "Data found";
	String excepctedSucessMessage;
	String actualStatus;
	String expectedStatus = "1";

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessGetAddressDetailsUrl API URl(HttpGet)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setUp() throws Exception {
		sepaBase = new SepaBase();
		businessGetAddressDetailsUrl = properties.getProperty("businessGetAddressDetails");
		businessGetAddressDetailsUrl = businessGetAddressDetailsUrl + SepaSprint2Base.APPLICANT_ID;
	}

	/**
	 * getAddressDetailsByApplicantId() - To execute the HTTPGET
	 * API(businessGetAddressDetailsUrl) It returns closebaleHttpResponse. We are
	 * parsing the obtained API Response and validating the response based on
	 * message, status & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void getAddressDetailsByApplicantId() throws Exception {
		sepaRequests = new SepaRequests();
		closebaleHttpResponse = sepaRequests.get(businessGetAddressDetailsUrl); // call the API
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		if (responseString.startsWith("[")) {
			JSONArray responseJsonArray = new JSONArray(responseString);
			int count = responseJsonArray.length();
			for (int i = 0; i < count; i++) {
				responseJson = responseJsonArray.getJSONObject(i);
			}
		} else {
			responseJson = new JSONObject(responseString);
		}
		excepctedSucessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		Assert.assertEquals(excepctedSucessMessage, actualSucessMessage);
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
	}

}

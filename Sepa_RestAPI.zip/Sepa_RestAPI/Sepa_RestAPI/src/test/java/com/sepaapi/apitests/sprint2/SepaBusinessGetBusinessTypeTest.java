package com.sepaapi.apitests.sprint2;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessGetBusinessTypeTest - CLASS -> HttpGET Request API which
 * retrieves all business Types.
 *
 */
public class SepaBusinessGetBusinessTypeTest extends SepaBase {

	SepaBase sepaBase;
	String businessTypeUrl;
	JSONObject responseJson;
	String business_id;
	SepaRequests sepaRequests;
	CloseableHttpResponse closebaleHttpResponse;

	/**
	 * setUp() - METHOD -> To load the properties file. Return - businessType API
	 * URl(HttpGet)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setUp() throws Exception {
		sepaBase = new SepaBase();
		businessTypeUrl = properties.getProperty("businessType");
	}

	/**
	 * getAllBusinessTypes() - To execute the HTTPGET API(businessType) It returns
	 * closebaleHttpResponse. We are parsing the obtained API Response and
	 * validating the response based on business_type_id and HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void getAllBusinessTypes() throws Exception {
		sepaRequests = new SepaRequests();
		closebaleHttpResponse = sepaRequests.get(businessTypeUrl);
		// a. Status Code:
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200, StatusCode_Err_200);
		// b. Json String:
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		if (responseString.startsWith("[")) {
			JSONArray responseJsonArray = new JSONArray(responseString);
			int count = responseJsonArray.length();
			for (int i = 0; i < count; i++) {
				responseJson = responseJsonArray.getJSONObject(i);
				business_id = ValidationUtils.getValueByJPath(responseJson, "/business_type_id");
				Assert.assertEquals(Integer.parseInt(business_id), i + 1);
			}
		} else {
			responseJson = new JSONObject(responseString);
		}
	}

}

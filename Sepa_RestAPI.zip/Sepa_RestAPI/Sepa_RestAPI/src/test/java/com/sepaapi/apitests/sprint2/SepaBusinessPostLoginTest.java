package com.sepaapi.apitests.sprint2;

import java.util.HashMap;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessPostLoginTest - CLASS -> HttpPost Request , This API used to for
 * user authentication purpose it takes 3 parameters such as email,password and
 * mpin. While email will act as user_id you can use password or mpin as per
 * requirement. It takes NULL also.
 */
public class SepaBusinessPostLoginTest extends SepaBase {

	SepaBase sepaBase;
	String businessUserLoginUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String email;
	String expectedSuccessMesssage = "login successfull";
	String actualSuccessMessage;
	String actualStatus;
	String expectedStatus = "1";
	String expectedEmail;

	/**
	 * setUp() - METHOD -> To load the properties file. Return - businessUserLogin
	 * API URl(HttpPost)
	 * 
	 * @throws Exception
	 */
	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		businessUserLoginUrl = properties.getProperty("businessUserLogin");
	}

	/**
	 * doLogin() - METHOD -> To execute the HttpPost API(businessUserLogin) It
	 * returns JsonResponse, This API will it will log into application based on
	 * email and password ,mpin . which are provided by API Request Object and we
	 * are validating the obtained API response based on message ,status,email &
	 * HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */
	@Test
	public void doLogin() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness,
				"BusinessLoginDetails");
		// Data Drive from Excel
		String usersJsonString = excelUtils.DataEntry(0);
		// Json String
		StringBuffer stringBuffer = new StringBuffer(usersJsonString);
		stringBuffer.insert(11, SepaSprint2Base.EMAIL_ID);
		stringBuffer.insert(48, SepaSprint2Base.PASSWORD);
		String stringLogin = stringBuffer.toString();
		requestJSON = new JSONObject(stringLogin);
		String actualEmail = ValidationUtils.getValueByJPath(requestJSON, "/email");
		closebaleHttpResponse = sepaRequests.post(businessUserLoginUrl, stringLogin, headerMap); // call the API
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		responseJson = new JSONObject(responseString);
		expectedEmail = ValidationUtils.getValueByJPath(responseJson, "/userInfo/email");
		actualSuccessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualSuccessMessage, expectedSuccessMesssage);
		Assert.assertEquals(Integer.parseInt(actualStatus), Integer.parseInt(expectedStatus));
		Assert.assertEquals(actualEmail, expectedEmail);
	}
}

package com.sepaapi.apitests.sprint2;

import java.util.HashMap;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.sepaapi.base.SepaBase;
import com.sepaapi.requests.SepaRequests;
import com.sepaapi.utils.ExcelUtils;
import com.sepaapi.utils.ValidationUtils;

/**
 * SepaBusinessPostFileUploadTest - CLASS -> HttpPost Request API for the insert
 * files in database as base64 format based on business_id,file_content(base64),
 * File Name(Operating Address/Business Address/Share Holder Details and Signing
 * Authority) and File Type(.PNG/JPG/PDF)
 */

public class SepaBusinessPostFileUploadTest extends SepaBase {
	SepaBase sepaBase;
	String businessPostInsertFileUrl;
	SepaRequests sepaRequests;
	JSONObject responseJson;
	JSONObject requestJSON;
	CloseableHttpResponse closebaleHttpResponse;
	String expectedStatus = "1";
	String actualStatus;
	String expectedSucessMessage = "File uploded";
	String actualSucessMessage;

	/**
	 * setUp() - METHOD -> To load the properties file. Return -
	 * businessPostInsertFile API URl(HttpPost)
	 * 
	 * @throws Exception
	 */

	@BeforeMethod
	public void setup() throws Exception {
		sepaBase = new SepaBase();
		businessPostInsertFileUrl = properties.getProperty("businessPostInsertFile");
	}

	/**
	 * fileUpload() - METHOD -> To execute the HttpPost API(businessPostInsertFile)
	 * It returns JsonResponse and We are parsing the obtained API Response and
	 * validating the response based on Message and status & HTTPStatus Codes.
	 * 
	 * @throws Exception
	 */

	@Test
	public void fileUpload() throws Exception {
		sepaRequests = new SepaRequests();
		HashMap<String, String> headerMap = new HashMap<String, String>();
		headerMap.put("Content-Type", "application/json");
		ExcelUtils excelUtils = new ExcelUtils(System.getProperty("user.dir") + TestDataPathBusiness, "InsertFile");
		// Data Drive from Excel
		String usersJsonString = excelUtils.DataEntry(0);
		// Json String
		StringBuffer st = new StringBuffer(usersJsonString);
		st.insert(16, SepaSprint2Base.BUSINESS_ID);
		String stringRegReq = st.toString();
		requestJSON = new JSONObject(stringRegReq);
		closebaleHttpResponse = sepaRequests.post(businessPostInsertFileUrl, stringRegReq, headerMap); // call the API
		int statusCode = closebaleHttpResponse.getStatusLine().getStatusCode();
		Assert.assertEquals(statusCode, RESPONSE_STATUS_CODE_200);
		String responseString = EntityUtils.toString(closebaleHttpResponse.getEntity(), "UTF-8");
		responseJson = new JSONObject(responseString);
		actualStatus = ValidationUtils.getValueByJPath(responseJson, "/status");
		Assert.assertEquals(actualStatus, expectedStatus);
		actualSucessMessage = ValidationUtils.getValueByJPath(responseJson, "/message");
		Assert.assertEquals(actualSucessMessage, expectedSucessMessage);
	}
}

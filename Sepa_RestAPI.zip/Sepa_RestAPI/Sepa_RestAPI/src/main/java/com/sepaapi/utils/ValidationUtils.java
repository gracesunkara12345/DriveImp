package com.sepaapi.utils;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * ValidationUtils - To read the specific response Key value from obtained API Response to assert the result. 
 */
public class ValidationUtils {
	
	public static String getValueByJPath(JSONObject responseJson, String jPath) throws JSONException{
		Object object = responseJson;
		for(String s : jPath.split("/")) 
			if(!s.isEmpty()) 
				if(!(s.contains("[") || s.contains("]")))
					object = ((JSONObject) object).get(s);
				else if(s.contains("[") || s.contains("]"))
					object = ((JSONArray) ((JSONObject) object).get(s.split("\\[")[0])).get(Integer.parseInt(s.split("\\[")[1].replace("]", "")));
		return object.toString();
	}

}

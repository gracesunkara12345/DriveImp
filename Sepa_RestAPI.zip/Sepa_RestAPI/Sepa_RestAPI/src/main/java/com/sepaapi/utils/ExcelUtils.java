package com.sepaapi.utils;

import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * ExcelUtils - To Read Excel sheet data and providing data based on rows
 * and columns--(Data Driven) Excel Utility class
 */
public class ExcelUtils {

	static XSSFWorkbook workBook;
	static XSSFSheet sheet;
	int columnCount;

	/**
	 * DataEntry - Method(To read the excel sheet data based on rows and columns)
	 * 
	 * @param Column Number (Integer)
	 * @return cell data (String)
	 */
	public String DataEntry(int i) {
		columnCount = getColumnCount();
		String data = getCellData(1, i);
		return data;
	}

	/**
	 * ExcelUtils - Constructor(which executes at the time of object Creation for
	 * this class) To load the workbook and sheet.
	 * 
	 * @param excelPath (String - Excel File Path)
	 * @param sheetName (String - SheetName in Excel File)
	 */
	public ExcelUtils(String excelPath, String sheetName) {
		try {
			workBook = new XSSFWorkbook(excelPath);
			sheet = workBook.getSheet(sheetName);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * getRowCount - Method To get the rows count of current sheet in Excel File.
	 * 
	 * @return count of rows (Integer)
	 */
	public int getRowCount() {
		int rowCount = 0;
		try {
			rowCount = sheet.getPhysicalNumberOfRows();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rowCount;
	}

	/**
	 * getColumnCount - Method To get the columns count of current sheet in Excel
	 * File.
	 * 
	 * @return count of columns (Integer)
	 */
	public int getColumnCount() {
		int colCount = 1;
		try {
			colCount = sheet.getRow(0).getPhysicalNumberOfCells();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return colCount;
	}

	/**
	 * getCellData - Method(To read the excel sheet data based on rows and columns)
	 * 
	 * @param Column Number (Integer)
	 * @param Row    Number (Integer)
	 * @return cell data (String)
	 */
	public String getCellData(int rowNum, int colNum) {
		String cellData = null;
		try {
			cellData = sheet.getRow(rowNum).getCell(colNum).getStringCellValue();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return cellData;
	}

}


package com.sepaapi.requests;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPatch;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.testng.Assert;

import com.sepaapi.base.SepaBase;

/**
 * SEPA REQUESTS -- Class It consists of GET,POST,PUT,PATCH and DELETE request methods with and
 * without headers.
 */
public class SepaRequests extends SepaBase {
	
	/**
	 * GET Method without Headers: To execute the given API using HttpGet Request
	 * 
	 * @param url
	 * @return JSON Response(closebaleHttpResponse)
	 */
	public CloseableHttpResponse get(String url) {
		CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpGet httpGet = new HttpGet(url); // http get request
		CloseableHttpResponse closebaleHttpResponse = null;
		try {
			closebaleHttpResponse = httpClient.execute(httpGet);
			return closebaleHttpResponse;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return closebaleHttpResponse;
	}

	/**
	 * GET Method with Headers: To execute the given API using HttpGet Request
	 * 
	 * @param url
	 * @return JSON Response(closebaleHttpResponse)
	 */
	public CloseableHttpResponse get(String url, HashMap<String, String> headerMap) {
		CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpGet httpGet = new HttpGet(url); // http get request

		for (Map.Entry<String, String> entry : headerMap.entrySet()) {
			httpGet.addHeader(entry.getKey(), entry.getValue());
		}
		CloseableHttpResponse closebaleHttpResponse = null;
		try {
			closebaleHttpResponse = httpClient.execute(httpGet);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return closebaleHttpResponse;
	}

	
	
	/**
	 * POST Method without Headers: To execute the given API using HttpGet Request
	 * 
	 * @param url
	 * @return JSON Response(closebaleHttpResponse)
	 */
	public CloseableHttpResponse post(String url) {
		CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(url); // http Post request
		CloseableHttpResponse closebaleHttpResponse = null;
		try {
			closebaleHttpResponse = httpClient.execute(httpPost);
			return closebaleHttpResponse;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return closebaleHttpResponse;
	}

	/**
	 * POST Method with Headers: To execute the given API using HttpPost Request
	 * 
	 * @param url
	 * @return JSON Response(closebaleHttpResponse)
	 */
	public CloseableHttpResponse post(String url, String entityString, HashMap<String, String> headerMap) {
		CloseableHttpClient httpClient = HttpClients.createDefault();
		HttpPost httpPost = new HttpPost(url); // http post request
		try {
			httpPost.setEntity(new StringEntity(entityString));
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		// for headers:
		for (Map.Entry<String, String> entry : headerMap.entrySet()) {
			httpPost.addHeader(entry.getKey(), entry.getValue());
		}
		CloseableHttpResponse closebaleHttpResponse = null;
		try {
			closebaleHttpResponse = httpClient.execute(httpPost);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return closebaleHttpResponse;
	}
	
	

	/**
	 * PUT Method without Headers: To execute the given API using HttpPUT Request
	 * 
	 * @param url,Json(Pay_Load)
	 * @return 
	 * @return JSON Response
	 */
	public static String put(String json,String url) throws IOException {
        try (CloseableHttpClient httpclient = HttpClients.createDefault()) {
            HttpPut httpPut = new HttpPut(url);
            httpPut.setHeader("Accept", "application/json");
            httpPut.setHeader("Content-type", "application/json");
           
            StringEntity stringEntity = new StringEntity(json);
            httpPut.setEntity(stringEntity);

            // Create a custom response handler
            ResponseHandler < String > responseHandler = response -> {
                int status = response.getStatusLine().getStatusCode();
                if (status >= 200 && status < 300) {
                    HttpEntity entity = response.getEntity();
                    Assert.assertEquals(status, RESPONSE_STATUS_CODE_200);
                    return entity != null ? EntityUtils.toString(entity) : null;
                } else {
                    throw new ClientProtocolException("Unexpected response status: " + status);
                }
            };
            String responseBody = httpclient.execute(httpPut, responseHandler);
            return responseBody;
        }
    }
	
	/**
	 * PATCH Method without Headers: To execute the given API using HttpPATCH Request
	 * 
	 * @param url,Json(Pay_Load)
	 * @return 
	 * @return JSON Response
	 */
	public static String patch(String json,String url) throws IOException {
        try (CloseableHttpClient httpclient = HttpClients.createDefault()) {
            HttpPatch httpPatch = new HttpPatch(url);
            httpPatch.setHeader("Accept", "application/json");
            httpPatch.setHeader("Content-type", "application/json");
           
            StringEntity stringEntity = new StringEntity(json);
            httpPatch.setEntity(stringEntity);

            // Create a custom response handler
            ResponseHandler < String > responseHandler = response -> {
                int status = response.getStatusLine().getStatusCode();
                if (status >= 200 && status < 300) {
                    HttpEntity entity = response.getEntity();
                    Assert.assertEquals(status, RESPONSE_STATUS_CODE_200);
                    return entity != null ? EntityUtils.toString(entity) : null;
                } else {
                    throw new ClientProtocolException("Unexpected response status: " + status);
                }
            };
            String responseBody = httpclient.execute(httpPatch, responseHandler);
            return responseBody;
        }
    }
    
	/**
	 * DELETE Method without Headers: To execute the given API using HttpDELETE Request
	 * 
	 * @param url
	 * @return 
	 * @return JSON Response
	 */
	public static String delete(String url) throws IOException {
        try (CloseableHttpClient httpclient = HttpClients.createDefault()) {

            HttpDelete httpDelete = new HttpDelete(url);
            System.out.println("Executing request " + httpDelete.getRequestLine());

            // Create a custom response handler
            ResponseHandler < String > responseHandler = response -> {
                int status = response.getStatusLine().getStatusCode();
                if (status >= 200 && status < 300) {
                    HttpEntity entity = response.getEntity();
                    Assert.assertEquals(status, RESPONSE_STATUS_CODE_200);
                    return entity != null ? EntityUtils.toString(entity) : null;
                } else {
                    throw new ClientProtocolException("Unexpected response status: " + status);
                }
            };
            String responseBody = httpclient.execute(httpDelete, responseHandler);
            return responseBody;
        }
	}
}
	
	
package com.sepaapi.base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

import org.testng.annotations.Test;

/**
 * SepaBase - class
 * SepaBase class used in different testCases using extends keyword 
 * To initialize the properties file and retrieves the data.
 */
public class SepaBase {

	/**
	 * Pre Defined Response Status codes to validate API Response.
	 */
	
	public static int RESPONSE_STATUS_CODE_200 = 200;
	public int RESPONSE_STATUS_CODE_500 = 500;
	public int RESPONSE_STATUS_CODE_400 = 400;
	public int RESPONSE_STATUS_CODE_401 = 401;
	public int RESPONSE_STATUS_CODE_201 = 201;

	public String StatusCode_Err_200 = "Status code is not 200";
	public Properties properties;
	public String propertiesFilePath = "\\src\\main\\java\\com\\sepaapi\\config\\config.properties";
	public String TestDataPath	=	"/TestData/TestData_APIFrameworkSprint1.xlsx";
	public String TestDataPathBusiness = "/TestData/TestData_BusinessAPIFrameworkSprint2.xlsx";
	public String TestData_Path		=	"/TestData/TestData_APIFrameworkSprint3.xlsx";
	
	
	/**
	 * To Read Data from Properties File Such as API URL..etc
	 * @return the property from properties File based on key value.
	 */
	

	public SepaBase() {
		try {
			properties = new Properties();
			FileInputStream fileInputStream = new FileInputStream(System.getProperty("user.dir") + propertiesFilePath);
			properties.load(fileInputStream);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String ReadOTP( String email) {
		  
		    
		 String JDBC_DRIVER = "org.mariadb.jdbc.Driver";
	    final String DB_URL = properties.getProperty("dataBaseUrl");
	    final String USER = properties.getProperty("dataBaseUserName");
	    final String PASS = properties.getProperty("dataBasePassword");
	
		  // Reading the OTP of Email  from DataBase by passing the specific parameters
		        Connection conn = null;
		        Statement stmt = null;
		        String query;
		        String otpValue = null;
		        ResultSet rs = null;

		        try {

		            Class.forName(JDBC_DRIVER);
		            conn = DriverManager.getConnection(DB_URL, USER, PASS);
		            stmt = conn.createStatement();

		           
		                query = "select otp from token_validator where mobile_no = '"+email+"'";
		                rs = stmt.executeQuery(query);
		            
		            
		            while (rs.next()) {
		                otpValue = rs.getString("otp");
		                
		            }

		         rs.close();
		            stmt.close();
		            conn.close();
		        } catch (Exception e) {
		            e.printStackTrace();
		        } finally {
		            try {
		                if (stmt != null)
		                    stmt.close();
		            } catch (Exception se2) {
		            }
		            try {
		                if (conn != null)
		                    conn.close();
		            } catch (Exception se) {
		                se.printStackTrace();
		            }
		        }
		        System.out.println(otpValue);
		        return otpValue;

		    }
	
}
